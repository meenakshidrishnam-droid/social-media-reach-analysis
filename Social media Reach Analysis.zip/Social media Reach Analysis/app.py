import streamlit as st
import pandas as pd
import plotly.express as px

# Page Config
st.set_page_config(
    page_title="Social Media Reach Analysis",
    page_icon="📱",
    layout="wide"
)

st.title("📱 Social Media Reach Analysis Dashboard")

# Load CSV
df = pd.read_csv("social_media_reach.csv")

# Convert Date
df["Date"] = pd.to_datetime(df["Date"])

# KPIs
st.subheader("📊 Key Performance Indicators")

col1, col2, col3, col4 = st.columns(4)

col1.metric("Total Reach", f"{df['Reach'].sum():,}")
col2.metric("Total Impressions", f"{df['Impressions'].sum():,}")
col3.metric("Total Likes", f"{df['Likes'].sum():,}")
col4.metric("Total Followers", f"{df['Follows'].sum():,}")

st.divider()

# Dataset Preview
st.subheader("📋 Dataset Preview")
st.dataframe(df, use_container_width=True)

st.divider()

# Reach Trend
st.subheader("📈 Reach Trend")

fig1 = px.line(
    df,
    x="Date",
    y="Reach",
    markers=True,
    title="Reach Over Time"
)

st.plotly_chart(fig1, use_container_width=True)

# Impressions vs Reach
st.subheader("📊 Impressions vs Reach")

fig2 = px.scatter(
    df,
    x="Impressions",
    y="Reach",
    size="Likes",
    color="Post_Type",
    hover_data=["Comments", "Shares"],
    title="Impressions vs Reach"
)

st.plotly_chart(fig2, use_container_width=True)

# Engagement Metrics
st.subheader("❤️ Engagement Analysis")

engagement = df[["Likes", "Comments", "Shares", "Saves"]].sum()

eng_df = pd.DataFrame({
    "Metric": engagement.index,
    "Value": engagement.values
})

fig3 = px.bar(
    eng_df,
    x="Metric",
    y="Value",
    title="Total Engagement Metrics"
)

st.plotly_chart(fig3, use_container_width=True)

# Top Posts
st.subheader("🏆 Top 5 Posts by Reach")

top_posts = df.sort_values(
    by="Reach",
    ascending=False
).head(5)

fig4 = px.bar(
    top_posts,
    x="Date",
    y="Reach",
    color="Post_Type",
    title="Top Posts"
)

st.plotly_chart(fig4, use_container_width=True)

# Correlation Heatmap
st.subheader("🔥 Correlation Heatmap")

corr = df.select_dtypes(include="number").corr()

fig5 = px.imshow(
    corr,
    text_auto=True,
    aspect="auto",
    title="Correlation Matrix"
)

st.plotly_chart(fig5, use_container_width=True)

# Insights
st.subheader("📝 Insights")

best_post = df.loc[df["Reach"].idxmax()]

st.success(
    f"Highest Reach Post: {best_post['Post_Type']} on {best_post['Date'].date()} with Reach = {best_post['Reach']}"
)

st.info(
    f"Average Reach: {round(df['Reach'].mean(), 2)}"
)

st.info(
    f"Average Likes: {round(df['Likes'].mean(), 2)}"
)

# Footer
st.markdown("---")
st.markdown("Developed using Streamlit for Social Media Reach Analysis")